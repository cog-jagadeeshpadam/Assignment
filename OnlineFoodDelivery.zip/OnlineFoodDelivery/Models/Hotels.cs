using System.ComponentModel.DataAnnotations;

namespace OnlineFoodDelivery.Models
{
    public class Hotels
    {
        // Implement code here
    }
}
