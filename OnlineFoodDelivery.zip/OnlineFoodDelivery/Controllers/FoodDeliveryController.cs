using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using OnlineFoodDelivery.Data;
using OnlineFoodDelivery.Models;

namespace OnlineFoodDelivery.Controllers
{
    public class FoodDeliveryController 
    {
       // Implement code here
    }
}
