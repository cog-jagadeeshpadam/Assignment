using Microsoft.AspNetCore.Mvc;
using OnlineFoodDelivery.Models;
using System.Diagnostics;

namespace OnlineFoodDelivery.Controllers
{
    public class HomeController
    {
        // Implement code here

    }
}
