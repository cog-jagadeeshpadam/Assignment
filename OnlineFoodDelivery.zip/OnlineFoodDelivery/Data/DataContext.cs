using Microsoft.EntityFrameworkCore;
using OnlineFoodDelivery.Models;

namespace OnlineFoodDelivery.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions Option) : base(Option)
        {

        }

        // Implement code here

    
        //DO NOT MAKE ANY CHANGES IN THIS BELOW-MENTIONED METHOD
        //Please un-comment the below-given code before submitting/evaluating    
        // protected override void OnModelCreating(ModelBuilder modelBuilder)
        // {
        //     modelBuilder.Entity<Hotels>().HasKey(k => k.HotelId);
        //     modelBuilder.Entity<Menu>().HasKey(k => k.MenuId);
        //     modelBuilder.Entity<Order>().HasKey(k => k.Id);
           



        //     modelBuilder.Entity<Menu>()
        //   .HasOne(b => b.hotels)
        //   .WithMany()
        //   .HasForeignKey(b => b.HotelId);

        //     modelBuilder.Entity<Order>()
        //   .HasOne(b => b.menu)
        //   .WithMany()
        //   .HasForeignKey(b => b.MenuId);

          

        //     modelBuilder.Entity<Menu>().Property(p => p.Price).HasPrecision(18, 4);
        //     modelBuilder.Entity<Order>().Property(p => p.Quantity).HasPrecision(18, 4);
        // }


    }
}
